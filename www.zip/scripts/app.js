'use strict';
angular.module('main', [
  'ionic',
  'ngCordova',
  'ui.router',
  'uiGmapgoogle-maps',
  // TODO: load other modules selected during generation
]).config(function (uiGmapGoogleMapApiProvider) {
  uiGmapGoogleMapApiProvider.configure({
    key: 'AIzaSyBCbmCVzXuxZa8CvmJbctfWOdCn9wjhtiE',
    v: '3.20', //defaults to latest 3.X anyhow
    libraries: 'weather,geometry,visualization'
  });
})
.config(function ($stateProvider, $urlRouterProvider) {

  // ROUTING with ui.router
  $urlRouterProvider.otherwise('/main/home');
  $stateProvider
    // this state is placed in the <ion-nav-view> in the index.html
    .state('main', {
      url: '/main',
      abstract: true,
      templateUrl: 'main/templates/tabs.html'
    })
    .state('main.home', {
      url: '/home',
      views: {
        'tab-home': {
          templateUrl: 'main/templates/home.html',
          controller: 'HomeController as ctrl'
        }
      }
    })
      .state('main.journey', {
        url: '/journey',
        views: {
          'tab-list': {
            templateUrl: 'main/templates/journey.html',
            controller: 'JourneyController as ctrl'
          }
        }
      })
      .state('main.journeys', {
        url: '/journeys',
        views: {
          'tab-journeys': {
            templateUrl: 'main/templates/journeys.html',
            controller: 'AllJourneysController as ctrl'
          }
        }
      })
      .state('main.journeywaypoints', {
        url: '/{journeyId}/waypoints',
        controller: function ($stateParams) {
          $stateParams.journeyId;
        },
        views: {
          'tab-list': {
            templateUrl: 'main/templates/journeywaypoints.html',
            controller: 'JourneyWaypointsController as ctrl'
          }
        }
      })
      .state('main.journeyback', {
        url: '/journeyback/{journeyId}',
        controller: function ($stateParams) {
          $stateParams.journeyId;
        },
        views: {
          'tab-list': {
            templateUrl: 'main/templates/journeyback.html',
            controller: 'JourneyBackController as ctrl'
          }
        }
      });
});

'use strict';

angular
  .module('main')
  .service('WaypointService', ['$http', 'WaypointFactory', function ($http, WaypointFactory) {
    var self = this;

    var DOMAIN = 'https://wayback-junyuanx-2.c9users.io';

    self.createWaypoint = function (journeyId, coordinates) {
      var data = { 'waypoint': { 'latitude': coordinates.latitude, 'longitude': coordinates.longitude } };
      return $http.post(DOMAIN + '/journeys/' + journeyId + '/waypoints', data)
        .then(_createWaypointCallBack, _errorCallBack);
    };

    function _createWaypointCallBack (response) {
      var lat = parseFloat(response.data.latitude);
      var lng = parseFloat(response.data.longitude);
      var waypoint = new WaypointFactory(lat, lng);
      waypoint.id = response.data.id;
      return waypoint;
    }

    self.updateWaypoint = function (waypoint) {
      var data = { 'waypoint': { 'description': waypoint.description } };
      return $http.patch(DOMAIN + '/waypoints/' + waypoint.id, data).then(_successCallBack, _errorCallBack);
    };

    self.deleteWaypoint = function (waypointId) {
      return $http.delete(DOMAIN + '/waypoints/' + waypointId).then(_successCallBack, _errorCallBack);
    };

    function _successCallBack () { return; }

    function _errorCallBack () { return; }
  }]);

'use strict';
angular.module('main')
.service('Main', function ($log, $timeout) {

  $log.log('Hello from your Service: Main in module main');

  // some initial data
  this.someData = {
    binding: 'Yes! Got that databinding working'
  };

  this.changeBriefly = function () {
    var initialValue = this.someData.binding;
    this.someData.binding = 'Yeah this was changed';

    var that = this;
    $timeout(function () {
      that.someData.binding = initialValue;
    }, 500);
  };

});

'use strict';

angular
  .module('main')
  .service('LocationService', ['$cordovaGeolocation', function ($cordovaGeolocation) {
    var self = this;
    var options = {timeout: 25000, enableHighAccuracy: true};
    var watch = $cordovaGeolocation.watchPosition(options);
    self.currentLocation = null;

    self.getCurrentLocation = function () {
      return self.currentLocation;
    };

    self.watchLocation = function () {
      watch.then(null, function (err) {
        return err;
      }, function (position) {
        self.currentLocation = position.coords;
        return position;
      });
    };
  }]);

'use strict';

angular
  .module('main')
  .service('JourneyService', ['$http', 'JourneyFactory', 'WaypointFactory', function ($http, JourneyFactory, WaypointFactory) {
    var self = this;

    var DOMAIN = 'https://wayback-junyuanx-2.c9users.io';

    _clearCurrentJourney();

    self.getCurrentJourney = function () {
      return self.currentJourney;
    };

    self.getJourney = function (journeyId) {
      return $http.get(DOMAIN + '/journeys/' + journeyId)
        .then(_getJourneyCallBack, _errorCallBack);
    };

    function _getJourneyCallBack (response) {
      var journey = _parseJourneyData(response);
      journey.waypoints = _parseWaypointData(response.data.waypoints);
      self.currentJourney = journey;
      return journey;
    }

    function _parseJourneyData (response) {
      var journey = new JourneyFactory(response.data.journey.description);
      journey.id = response.data.journey.id;
      return journey;
    }

    self.getAllJourneys = function () {
      return $http.get(DOMAIN + '/journeys/').then(_getAllJourneysCallback, _errorCallBack);
    };

    function _getAllJourneysCallback (response) {
      var journeys = _createJourneys(response.data);
      return journeys;
    }

    function _parseWaypointData (wpArray) {
      return wpArray.map(function (wpData) {
        var waypoint = new WaypointFactory(wpData.latitude, wpData.longitude, wpData.description, wpData.id);
        return waypoint;
      });
    }

    self.startJourney = function () {
      var data = { 'journey': { 'description': '' } };
      return $http.post(DOMAIN + '/journeys', data)
        .then(_startJourneyCallBack, _errorCallBack);
    };

    function _startJourneyCallBack (response) {
      var journey = new JourneyFactory();
      journey.id = response.data.id;
      self.currentJourney = journey;
      return journey;
    }

    self.updateJourney = function (journeyId, descText) {
      var data = { 'journey': { 'description': descText } };
      return $http.patch(DOMAIN + '/journeys/' + journeyId, data)
        .then(_successCallBack, _errorCallBack);
    };

    self.deleteJourney = function (journeyId) {
      return $http.delete(DOMAIN + '/journeys/' + journeyId)
        .then(_clearCurrentJourney, _errorCallBack);
    };

    function _clearCurrentJourney () {
      self.currentJourney = null;
    }

    function _successCallBack (err) { return; }

    function _errorCallBack (err) { return err; }


    function _createJourneys (journeyArray) {
      var journeys = journeyArray.map(function (journey) {
        var journeyObject = new JourneyFactory(journey.description, journey.id);
        return journeyObject;
      });
      return journeys;
    }
  }]);

'use strict';

angular
  .module('main')
  .factory('WaypointFactory', function () {
    var Waypoint = function (lat, long, description, id) {
      this.coords = {latitude: lat, longitude: long};
      this.description = description || '';
      this.imageURI = null;
      this.reached = false;
      this.id = id;
    };

    Waypoint.prototype.updateImageURI = function (path) {
      this.imageURI = path;
    };

    Waypoint.prototype.markAsReached = function () {
      this.reached = true;
    };

    return Waypoint;
  });

'use strict';

angular
  .module('main')
  .factory('JourneyFactory', function () {
    var Journey = function (description, id) {
      this.waypoints = [];
      this.description = description || '';
      this.id = id;
    };

    Journey.prototype.addWaypoint = function (waypoint) {
      this.waypoints.push(waypoint);
    };

    return Journey;
  });

'use strict';

angular
  .module('main')
  .controller('JourneyWaypointsController', ['JourneyService', '$stateParams',
    function (JourneyService, $stateParams) {
      var self = this;

      self.getAllJourneyWaypoints = function () {
        var journeyId = parseInt($stateParams.journeyId);
        return JourneyService.getJourney(journeyId).then(function (journey) {
          if (typeof journey !== 'undefined' ) {
            self.journey = journey;
            self.allJourneyWaypoints = journey.waypoints;
          }
        });
      };

      self.allJourneyWaypoints = self.getAllJourneyWaypoints();
    }]);

'use strict';

angular
  .module('main')
  .controller('JourneyController', ['$scope', '$cordovaCamera', '$cordovaFile', 'JourneyService', '$location', 'WaypointService', 'uiGmapGoogleMapApi', 'LocationService',
    function ($scope, $cordovaCamera, $cordovaFile, JourneyService, $location, WaypointService, uiGmapGoogleMapApi, LocationService) {

      _loadCurrentJourneyFromService();

      $scope.currentLocation = null;
      LocationService.watchLocation();
      var currentLocation = LocationService.getCurrentLocation();
      $scope.map = {center: {latitude: 51.517480, longitude: -0.073281}, zoom: 15 };

      watchLocation();


      $scope.createWaypoint = function () {

        $scope.journey = JourneyService.getCurrentJourney();

        if (typeof $scope.journey !== undefined) {
          WaypointService.createWaypoint($scope.journey.id, LocationService.getCurrentLocation())
            .then(function (waypoint) {
              waypoint.marker = {};
              $scope.journey.addWaypoint(waypoint);
              $scope.map = {center: {latitude: parseFloat(waypoint.coords.latitude), longitude: parseFloat(waypoint.coords.longitude)}, zoom: 15 };
            });
        }
      };

      $scope.editJourneyDescription = function (descText) {
        $scope.journey.description = descText;
        JourneyService.updateJourney($scope.journey.id, descText);
      };

      function watchLocation () {
        $scope.$watch(function () {
          return LocationService.getCurrentLocation();
        }, function (oldLocation, currentLocation) {});
      }

      $scope.editWaypointDescription = function (descText) {
        var lastWaypoint = $scope.getLastWaypoint();
        lastWaypoint.description = descText;
        WaypointService.updateWaypoint(lastWaypoint);
      };

      $scope.getLastWaypoint = function () {
        var waypoints = $scope.journey.waypoints;
        return waypoints[waypoints.length - 1];
      };

      $scope.loadAllJourneys = function () {
        $location.path('/main/journeys');
      };

      function _loadCurrentJourneyFromService () {
        $scope.journey = JourneyService.getCurrentJourney();
      }

      $scope.takePhoto = function () {
        var options = {
          quality: 50,
          destinationType: Camera.DestinationType.DATA_URL,
          sourceType: Camera.PictureSourceType.CAMERA,
          allowEdit: true,
          encodingType: Camera.EncodingType.JPEG,
          targetWidth: 100,
          targetHeight: 100,
          popoverOptions: CameraPopoverOptions,
          saveToPhotoAlbum: true
        };

        $cordovaCamera.getPicture(options)
          .then(function (imageData) {
            $scope.imgURI = 'data:image/jpeg;base64,' + imageData;

            var waypoints = $scope.journey.waypoints;
            var lastWaypoint = waypoints[waypoints.length - 1];
            lastWaypoint.updateImageURI('data:image/jpeg;base64,' + imageData);

          }, function (err) {
            console.log('Error:' + error);
          });
      };
    }]);

'use strict';

angular
  .module('main')
  .controller('JourneyBackController', ['$timeout', '$scope', 'JourneyFactory', 'JourneyService', 'WaypointService', '$stateParams', 'LocationService',
    function ($timeout, $scope, JourneyFactory, JourneyService, WaypointService, $stateParams, LocationService) {

      $scope.distanceFromWaypoint = '';
      $scope.notificationMessage = '';

      $scope.startJourneyBack = function () {
        var journeyId = parseInt($stateParams.journeyId);
        JourneyService.getJourney(journeyId).then(function (journey) {
          $scope.journey = journey;
          $scope.map = {center: {latitude: 51.517480, longitude: -0.073281}, zoom: 15 };
          LocationService.watchLocation();
          $scope.currentWaypoint = getFirstWaypoint();
          watchLocation();
        });
      };


    //find out what the current Waypoint is
    //trigger an action when distance from current waypoint reaches a certain value

      $scope.startJourneyBack();

      function markAsReached (waypoint) {
        WaypointService.deleteWaypoint(waypoint.id).then(function () {
          waypoint.markAsReached();
        });
      }

      $scope.deleteJourney = function () {
        JourneyService.deleteJourney($scope.journey.id);
      };

      var distanceBetween = function (start, end) {
        if (start && end) {
          var p = 0.017453292519943295;    // Math.PI / 180
          var c = Math.cos;
          var a = 0.5 - c((end.latitude - start.latitude) * p) / 2 +
              c(start.latitude * p) * c(end.latitude * p) *
              (1 - c((end.longitude - start.longitude) * p)) / 2;
          return 12742 * Math.asin(Math.sqrt(a)) * 1000;
        }
        return 'Location not ready';
      };

      function watchLocation () {
        $scope.$watch(function () {
          return LocationService.getCurrentLocation();
        }, function (oldLocation, currentLocation) {
          $scope.currentLocation = currentLocation;
          $scope.currentLocation.center = {
            latitude: $scope.currentLocation.latitude,
            longitude: $scope.currentLocation.longitude
          };

          $scope.currentLocation.stroke = {
            color: '#66CCFF',
            weight: 1,
            opacity: 0.8
          };

          $scope.currentLocation.fill = {
            color: '#66CCFF',
            opacity: 0.6
          };

          if (isCloseEnoughToWaypoint()) {
            changeCurrentWaypoint();
          }
          $scope.distanceFromWaypoint = _displayDistanceBetween(currentLocation, $scope.currentWaypoint.coords);
        });
      }

      function _displayDistanceBetween (location, waypoint) {
        var distance = distanceBetween(location, waypoint);
        var roundedDistance = Math.round(distance);
        return roundedDistance + 'm';
      }

      function getFirstWaypoint () {
        reverseWaypoints();
        return $scope.journey.waypoints[0];
      }

      function reverseWaypoints () {
        $scope.journey.waypoints = $scope.journey.waypoints.reverse();
      }

      function isCloseEnoughToWaypoint () {
        return distanceBetween($scope.currentLocation, $scope.currentWaypoint.coords) < 10;
      }

      function changeCurrentWaypoint () {
        var currentWaypointIndex = $scope.journey.waypoints.indexOf($scope.currentWaypoint);
        $scope.currentWaypoint.icon = {url: 'http://maps.google.com/mapfiles/ms/icons/yellow-dot.png'};

        $scope.notificationMessage = "You've reached a waypoint!"

        $timeout(function () {
          $scope.notificationMessage = ''
        }, 2000);

        markAsReached($scope.journey.waypoints[currentWaypointIndex]);
        if ((currentWaypointIndex) > - 1 && (currentWaypointIndex !== ($scope.journey.waypoints.length - 1))) {
          $scope.currentWaypoint = $scope.journey.waypoints[currentWaypointIndex + 1];
        } else {
          $timeout(function () {
            $scope.notificationMessage = "Journey complete :)"
          }, 3000);
        }
      }
    }]);

'use strict';

angular
  .module('main')
  .controller('HomeController', ['JourneyFactory', 'JourneyService', '$location',
      function (JourneyFactory, JourneyService, $location) {
        var self = this;
        self.startJourney = function () {
          JourneyService.startJourney().then(function (journey) {
            if (typeof journey !== 'undefined' ) {
              $location.path('/main/journey');
            }
          });
        };
      }]);

'use strict';

angular
  .module('main')
  .controller('AllJourneysController', ['$scope', 'JourneyFactory', 'JourneyService', '$location',
    function ($scope, JourneyFactory, JourneyService, $location) {
      $scope.getAllJourneys = function () {
        JourneyService.getAllJourneys().then(function (journeys) {
          if (typeof journeys !== 'undefined' ) {
            $scope.allJourneys = journeys.reverse();
          }
        });
      };

      $scope.loadJourney = function (journeyId) {
        $location.path('/main/journeyback/' + journeyId);
      };

      $scope.loadJourneyWaypoints = function (journeyId) {
        $location.path('/main/' + journeyId + '/waypoints');
      };

      $scope.allJourneys = $scope.getAllJourneys();
    }]);


'use strict';

angular.module('Wayback', [
  // load your modules here
  'main' // starting with the main module
]);
